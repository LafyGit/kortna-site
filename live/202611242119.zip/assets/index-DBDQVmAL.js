const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-qir7r-RV.js","./index-CVUC6hs9.js","./index-B9Ln87Wv.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CVUC6hs9.js";const _=r("Share",{web:()=>t(()=>import("./web-qir7r-RV.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
