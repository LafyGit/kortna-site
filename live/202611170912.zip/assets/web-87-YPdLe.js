import{b2 as e}from"./index-DFBl3Jh4.js";class i extends e{async requestReview(){throw this.unimplemented("Not implemented on web.")}}export{i as InAppReviewWeb};
