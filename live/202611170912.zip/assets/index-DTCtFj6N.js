const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Pu3sONcp.js","./index-DFBl3Jh4.js","./index-CXbE0R4s.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DFBl3Jh4.js";const _=r("Share",{web:()=>t(()=>import("./web-Pu3sONcp.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
