const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Dged7sgd.js","./index-B-C_KOG7.js","./index-ypz_xKsV.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-B-C_KOG7.js";const o=r("App",{web:()=>p(()=>import("./web-Dged7sgd.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
