const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B-KCsYE0.js","./index-B-C_KOG7.js","./index-ypz_xKsV.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-B-C_KOG7.js";const _=r("Share",{web:()=>t(()=>import("./web-B-KCsYE0.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
