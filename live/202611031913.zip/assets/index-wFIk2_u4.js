const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BzN9gF1t.js","./index-DjCv8fgM.js","./index-ypz_xKsV.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DjCv8fgM.js";const _=r("Share",{web:()=>t(()=>import("./web-BzN9gF1t.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
