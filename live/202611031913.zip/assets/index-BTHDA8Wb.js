const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DwIROH0W.js","./index-DjCv8fgM.js","./index-ypz_xKsV.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-DjCv8fgM.js";const o=r("App",{web:()=>p(()=>import("./web-DwIROH0W.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
