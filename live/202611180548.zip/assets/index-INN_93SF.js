const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DeeOi9BY.js","./index-CVzjOu4O.js","./index-DtXMgxjw.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CVzjOu4O.js";const _=r("Share",{web:()=>t(()=>import("./web-DeeOi9BY.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
