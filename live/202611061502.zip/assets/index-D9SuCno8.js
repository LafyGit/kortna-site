const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DTAq5Ggi.js","./index-CAWdLMyZ.js","./index-BNxWgY9-.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CAWdLMyZ.js";const _=r("Share",{web:()=>t(()=>import("./web-DTAq5Ggi.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
