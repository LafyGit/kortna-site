const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B67HbXF0.js","./index-t0_NKCcz.js","./index-4FsLxSHr.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-t0_NKCcz.js";const _=r("Share",{web:()=>t(()=>import("./web-B67HbXF0.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
