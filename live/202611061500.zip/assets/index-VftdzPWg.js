const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BeyVwGj9.js","./index-t0_NKCcz.js","./index-4FsLxSHr.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-t0_NKCcz.js";const o=r("App",{web:()=>p(()=>import("./web-BeyVwGj9.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
