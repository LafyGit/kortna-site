const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cny9eA_x.js","./index-CPDaQ7qk.js","./index-D99TLma9.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CPDaQ7qk.js";const _=r("Share",{web:()=>t(()=>import("./web-Cny9eA_x.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
